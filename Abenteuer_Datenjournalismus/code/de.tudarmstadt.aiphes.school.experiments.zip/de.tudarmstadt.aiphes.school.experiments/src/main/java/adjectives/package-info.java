/**
 * @author Judith
 * 
 * extraction of an adjective lemma frequency list from 
 * lemmatized and POS-tagged text
 * 
 * run the *Pipeline class to perform the extraction
 *
 */
package adjectives;