package rawtext;

import static org.apache.uima.fit.util.JCasUtil.select;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasAnnotator_ImplBase;
import org.apache.uima.fit.descriptor.ConfigurationParameter;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

import de.tudarmstadt.ukp.dkpro.core.api.frequency.util.FrequencyDistribution;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;

public class StopwordExtractor extends JCasAnnotator_ImplBase 
{


    public static final String PARAM_OUTPUT_FILE = "OutputFile";
    @ConfigurationParameter(name = PARAM_OUTPUT_FILE, mandatory=true, description="Output path, where results file should be stored")
    protected File outputFile;
    
    private BufferedWriter dataWriter;  // File writer for results of counting

    
    private FrequencyDistribution<String> frequencyList = new FrequencyDistribution<String>();
    private int allTokens;
    
    
    
    @Override
    public void initialize(UimaContext aContext)
        throws ResourceInitializationException
    {
        super.initialize(aContext);        
    }


    @Override
    public void process(JCas aJCas) throws AnalysisEngineProcessException {
        try {
            for (Token token : select(aJCas, Token.class)) {  
              if (!token.getPos().getPosValue().matches("VV.*")
                  && !token.getPos().getPosValue().matches("N.*")
                  && !token.getPos().getPosValue().matches("ADJ.*")
                  ) { 
                  frequencyList.inc(token.getCoveredText());
                  allTokens++;
              }
            }   
        }
        catch (NullPointerException e2) {
            System.out.println("NullPointerException occured with this CAS - proceed to next one");
        }

    }
    
    
    @Override
    public void collectionProcessComplete() throws AnalysisEngineProcessException {
        
        try {
            System.out.println("number of all tokens: " +allTokens +"\n");
            
            dataWriter = new BufferedWriter(new FileWriter(outputFile));
            for (String item : frequencyList.getKeys()) {
                                                
                dataWriter.write(item +"\t" +frequencyList.getCount(item)
                        +"\n");
                dataWriter.flush();
            }
            dataWriter.close();
                        
        } catch (IOException e) {
            System.out.println("IOException - problem with " +outputFile);
            throw new AnalysisEngineProcessException();
        }
    }

    
}

