package rawtext;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.factory.CollectionReaderFactory.createReaderDescription;

import java.io.IOException;

import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.collection.CollectionReaderDescription;
import org.apache.uima.fit.pipeline.SimplePipeline;

import de.tudarmstadt.ukp.dkpro.core.io.text.TextReader;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolSegmenter;
import de.tudarmstadt.ukp.dkpro.core.matetools.MatePosTagger;


public class StopwordExtractionPipeline
{
    
    private static final String INPUT_FILE = "marvelUniversumFiguren_expanded.txt";
    private static final String INPUT_LOCATION = "input/";

    public static void main(String[] args)
        throws UIMAException, IOException
    {
        CollectionReaderDescription reader = createReaderDescription(TextReader.class,
                TextReader.PARAM_SOURCE_LOCATION, INPUT_LOCATION+INPUT_FILE,
                TextReader.PARAM_LANGUAGE, "de");
        
        AnalysisEngineDescription tokenizer = createEngineDescription(LanguageToolSegmenter.class);
        AnalysisEngineDescription posTagger = createEngineDescription(MatePosTagger.class);
                                                            
        AnalysisEngineDescription dataWriter = createEngineDescription(
                StopwordExtractor.class,
                StopwordExtractor.PARAM_OUTPUT_FILE, "output/"+"stopwords_"+INPUT_FILE
                );
                                  
        SimplePipeline.runPipeline(reader, 
                tokenizer, 
                posTagger, 
                dataWriter
                );        
    }
}
