package rawtext;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.factory.CollectionReaderFactory.createReaderDescription;

import java.io.File;

import org.apache.uima.fit.pipeline.SimplePipeline;

import de.tudarmstadt.ukp.dkpro.core.api.io.ResourceCollectionReaderBase;
import de.tudarmstadt.ukp.dkpro.core.io.imscwb.ImsCwbReader;
import de.tudarmstadt.ukp.dkpro.core.tokit.GermanSeparatedParticleAnnotator;

/**
 * Simple pipeline using a reader and a writer from the DKPro Core component collection. The
 * sdewac corpus is already tokenized, lemmatized and tagged with part-of-speech information,
 * so no extra components are needed to add these annotations.
 * The StopwordExtractor counts occurrences of tokens not tagged VV.*, N.*, ADJ.*
 * 
 * @author Eckle-Kohler
 * 
 */
public class StopwordExtractionPipelineSdewac
{
    
    final static String CORPUS_DIR = "/home/user-ukp/workspace/corpora/";
        
    public static void main(String[] args) throws Exception
    {  
                        

        
                SimplePipeline.runPipeline(
                    createReaderDescription(
                            ImsCwbReader.class,
                            ImsCwbReader.PARAM_ENCODING, "UTF-8",
                            ResourceCollectionReaderBase.PARAM_SOURCE_LOCATION,     new File(CORPUS_DIR+"dewac/filtered/").getAbsolutePath(),
                            ResourceCollectionReaderBase.PARAM_PATTERNS, new String[] { "*.tagged" },
                            ResourceCollectionReaderBase.PARAM_LANGUAGE, "de"),
                    createEngineDescription(GermanSeparatedParticleAnnotator.class),
                    createEngineDescription(StopwordExtractor.class,
                            StopwordExtractor.PARAM_OUTPUT_FILE, 
                            "output/"+"stopwords_sdewac")
                );

         
                            
    }
}
