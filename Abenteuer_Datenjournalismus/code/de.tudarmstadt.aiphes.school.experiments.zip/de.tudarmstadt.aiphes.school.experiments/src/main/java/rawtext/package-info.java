/**
 * @author Judith
 * 
 * extraction of a frequency list of non-content words from
 * POS-tagged text
 * 
 * run the *Pipeline class to perform the extraction
 *
 */
package rawtext;