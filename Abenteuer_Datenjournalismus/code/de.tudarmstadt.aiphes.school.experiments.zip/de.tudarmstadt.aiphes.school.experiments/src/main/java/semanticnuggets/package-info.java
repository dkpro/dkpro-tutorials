/**
 * @author Judith
 * 
 * extraction of a named entity frequency list from 
 * text with named entity annotations
 * 
 * extraction of a "topic" frequency list from 
 * lemmatized and POS-tagged text (excluding named entities)
 * 
 * 
 * run the *Pipeline class to perform the extraction
 *
 */
package semanticnuggets;