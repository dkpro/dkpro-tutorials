package verbs;

import static org.apache.uima.fit.util.JCasUtil.select;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasAnnotator_ImplBase;
import org.apache.uima.fit.descriptor.ConfigurationParameter;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

import de.tudarmstadt.ukp.dkpro.core.api.frequency.util.FrequencyDistribution;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;

/**
 * @author Judith
 * extracts a frequency list of 
 * all verb lemmas (only main verbs, no auxiliaries and modals)
 *
 */
public class VerblemmaExtractor extends JCasAnnotator_ImplBase 
{


    public static final String PARAM_OUTPUT_FILE = "OutputFile";
    @ConfigurationParameter(name = PARAM_OUTPUT_FILE, mandatory=true, description="Output path, where results file should be stored")
    protected File outputFile;
    
    private BufferedWriter dataWriter;  // File writer for results of counting

    
    private FrequencyDistribution<String> frequencyList = new FrequencyDistribution<String>();
    private int allTokens;
    
    
    @Override
    public void initialize(UimaContext aContext)
        throws ResourceInitializationException
    {
        super.initialize(aContext); 
        
    }


    @Override
    public void process(JCas aJCas) throws AnalysisEngineProcessException {
        try {
            for (Token token : select(aJCas, Token.class)) { 
                allTokens++;
                if (token.getPos().getPosValue().matches("VV.*")
                        ) { 
                    String lemma = null;
                    if (token.getLemma().getValue().contains("|")) {
                        String[] parts = token.getLemma().getValue().split("|");
                        lemma = parts[0].
                                replaceAll("\\[", "").replaceAll("\\]", "");
                    } else {
                        lemma = token.getLemma().getValue().
                                replaceAll("\\[", "").replaceAll("\\]", "");
                    }
                    frequencyList.inc(lemma);

                } 
            }   
        }
        catch (NullPointerException e2) {
            System.out.println("NullPointerException occured with this CAS - proceed to next one");
        }

    }
    
    
    @Override
    public void collectionProcessComplete() throws AnalysisEngineProcessException {
        
        try {
            System.out.println("number of all tokens: " +allTokens +"\n");
            dataWriter = new BufferedWriter(new FileWriter(outputFile)); 
            for (String item : frequencyList.getKeys()) {  
                dataWriter.write(item +"\t" +frequencyList.getCount(item)
                        +"\n");
                dataWriter.flush();
            }
            dataWriter.close();
            
            /*
             *  for the extraction of the top frequent items in the frequency list,
             *  this snippet can be used:           
             *  List<String> resultList = frequencyList.getMostFrequentSamples(500);  
             *        
             */
            
                        
        } catch (IOException e) {
            System.out.println("IOException - problem with " +outputFile);
            throw new AnalysisEngineProcessException();
        }
    }


    
}

