/**
 * @author Judith
 * 
 * extraction of a verb lemma frequency list from 
 * lemmatized and POS-tagged text
 * 
 * run the *Pipeline class to perform the extraction
 *
 */
package verbs;