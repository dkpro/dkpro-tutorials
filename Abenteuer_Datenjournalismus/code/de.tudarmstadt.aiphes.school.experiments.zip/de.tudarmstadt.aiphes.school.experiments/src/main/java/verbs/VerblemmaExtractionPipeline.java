package verbs;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.factory.CollectionReaderFactory.createReaderDescription;

import java.io.IOException;

import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.collection.CollectionReaderDescription;
import org.apache.uima.fit.pipeline.SimplePipeline;

import de.tudarmstadt.ukp.dkpro.core.io.text.TextReader;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolLemmatizer;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolSegmenter;
import de.tudarmstadt.ukp.dkpro.core.matetools.MatePosTagger;
import de.tudarmstadt.ukp.dkpro.core.tokit.GermanSeparatedParticleAnnotator;


public class VerblemmaExtractionPipeline
{
    
    private static final String INPUT_FILE = "marvelUniversum.txt";
    
    private static final String INPUT_LOCATION = "input/";

    public static void main(String[] args)
        throws UIMAException, IOException
    {
        CollectionReaderDescription reader = createReaderDescription(TextReader.class,
                TextReader.PARAM_SOURCE_LOCATION, INPUT_LOCATION+INPUT_FILE,
                TextReader.PARAM_LANGUAGE, "de");
        
        AnalysisEngineDescription tokenizer = createEngineDescription(LanguageToolSegmenter.class);
        AnalysisEngineDescription posTagger = createEngineDescription(MatePosTagger.class);
        AnalysisEngineDescription lemmatizer = createEngineDescription(LanguageToolLemmatizer.class);
        
        AnalysisEngineDescription separatedParticleAnnotator = createEngineDescription(GermanSeparatedParticleAnnotator.class);

                    
                                
        AnalysisEngineDescription dataWriter = createEngineDescription(
                VerblemmaExtractor.class,
                VerblemmaExtractor.PARAM_OUTPUT_FILE, "output/"+"verbs_"+INPUT_FILE
                );
                                  
        SimplePipeline.runPipeline(reader, 
                tokenizer, 
                posTagger, 
                lemmatizer, 
                separatedParticleAnnotator, 
                dataWriter
                );        
    }
}

